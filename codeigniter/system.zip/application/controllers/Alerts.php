<?php
class Alerts extends CI_Controller {

	public function index()
	{
		$data['alerts'] = $this->Alerts_model->get_alerts();

		

		$this->load->view('templates/dashboard/header');
		$this->load->view('templates/dashboard/sidebar');
		$this->load->view('alerts/index', $data);
		$this->load->view('templates/general/footer');
	}
}
