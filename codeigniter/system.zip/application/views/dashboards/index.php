<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
<script src="<?php echo base_url() ?>assets/socketio/socket_io_v2.js"></script>

dueiferui <?php echo $company_id; ?>
<div id="message">

</div>


<script>
	const socket = io.connect('http://localhost:3001');

	socket.on('connect', () => {
		console.log(`Connected with id ${socket.id}`);
		socket.emit('join', { company_id: <?php echo $company_id; ?> });
	});

	socket.on('newOrder', (data) => {
		console.log(`New order received: ${data.alert_id} company: ${data.company_id}`);
		// Do something with the data, e.g. update the UI

		const messageElement = document.getElementById('message');
		messageElement.innerHTML = data.message;

		// Make AJAX request to PHP file to get all other requests
		const xhr = new XMLHttpRequest();
		xhr.onreadystatechange = function() {
			if (this.readyState == 4 && this.status == 200) {
				console.log(this.responseText);
				// Process the response from the PHP file
			}
		};
		xhr.open('GET', 'get_orders.php', true);
		xhr.send();
	});
</script>
