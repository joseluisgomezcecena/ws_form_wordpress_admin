<?php
class LocationsModel extends CI_Model
{
	public function __construct()
	{
		$this->load->database();
	}
	
	public function get_plants($id = FALSE)
	{
		if($id === FALSE)
		{
			$query = $this->db->get('plants');
			return $query->result_array();
		}
		
		$query = $this->db->get_where('plants', array('plant_id' => $id));
		return $query->row_array();
	}
	
	public function add_plant()
	{
		$data = array(
			'plant_name' => $this->input->post('plant_name'),
			'plant_company_id' => $this->session->userdata('data')['company_id'],
		);
		
		return $this->db->insert('plants', $data);
	}
	
	public function edit_plant($id)
	{
		$data = array(
			'plant_name' => $this->input->post('plant_name')
		);
		
		$this->db->where('plant_id', $id);
		return $this->db->update('plants', $data);
	}
	
	public function delete_plant($id)
	{
		$this->db->where('plant_id', $id);
		$this->db->delete('plants');
		return true;
	}
}
