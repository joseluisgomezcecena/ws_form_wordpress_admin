<div class="row">
	<div class="card sb-card-shadow">
		<div class="card-body">
			<form id="myForm">
				<input type="text" name="plant_name">
				<button type="submit">Save</button>
			</form>
		</div>
	</div>
</div>



<script>
	$(document).ready(function() {
		// Handle form submission
		$('#myForm').submit(function(event) {
			event.preventDefault();

			// Get form data
			const formData = $(this).serialize();

			// Send AJAX request to controller
			$.ajax({
				url: '<?php echo base_url() ?>locations/save_plant',
				method: 'POST',
				data: formData,
				success: function(response) {
					console.log(response);
					alert('Data saved successfully!');
				},
				error: function(error) {
					console.error(error);
					alert('Error saving data!');
				}
			});
		});
	});
</script>
