<?php
class Dashboards extends CI_Controller {

	public function index() {
		//$data['dashboard'] = $this->dashboard_model->get_dashboard();

		$data['title'] = 'Dashboard';
		$data['company_id'] = $this->session->userdata('data')['company_id'];

		$this->load->view('templates/dashboard/header', $data);
		$this->load->view('templates/dashboard/sidebar', $data);
		$this->load->view('dashboards/index', $data);
		$this->load->view('templates/general/footer');
	}
}
