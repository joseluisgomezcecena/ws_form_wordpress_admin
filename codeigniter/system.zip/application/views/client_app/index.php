<div class="container mt-5">
	<div class="row mt-5">
		<div class="col-lg-9 mt-5">
			<div class="card sb-card-shadow card-hover col-lg-6">
				<div class="card-body">
					<h2>Alerta</h2>
					<p>ytfyfyf</p>
				</div>
			</div>
		</div>
		<div class="col-lg-3 mt-5">
			<h2>Alerts</h2>
		</div>
	</div>
</div>
