<?php
class Locations extends CI_Controller
{
	// ...Plants
	public function plants()
	{
		$data['plants'] = $this->LocationsModel->get_plants();
		$data['title'] = 'Plants';

		//form validation
		//$this->form_validation->set_rules('plant_name', 'Plant Name', 'required');

		//if($this->form_validation->run() === FALSE)
		//{
			$this->load->view('templates/dashboard/header', $data);
			$this->load->view('templates/dashboard/sidebar');
			$this->load->view('locations/plants', $data);
			$this->load->view('templates/general/footer');
		//}
		//else
		//{
			//$this->LocationsModel->add_plant();
			$this->session->set_flashdata('message', 'Plant has been added');
			//redirect('locations/plants');
		//}
	}


	public function save()
	{
		// Get form data
		$plant_name = $this->input->post('plant_name');

		// Save data to database or perform other actions as needed
		// ...
		$this->LocationsModel->add_plant();
		// Send response back to client
		echo 'Data saved successfully!';
	}


	public function edit_plant($id)
	{
		$data['plant'] = $this->LocationsModel->get_plants($id);
		$data['title'] = 'Edit Plant';
		$data['page'] = 'plants';

		//form validation
		$this->form_validation->set_rules('plant_name', 'Plant Name', 'required');

		if($this->form_validation->run() === FALSE)
		{
			$this->load->view('templates/dashboard/header', $data);
			$this->load->view('templates/dashboard/sidebar');
			$this->load->view('locations/edit_plant', $data);
			$this->load->view('templates/general/footer');
		}
		else
		{
			$this->LocationsModel->edit_plant($id);
			$this->session->set_flashdata('message', 'Plant has been updated');
			redirect('locations/plants');
		}
	}

	public function delete_plant($id)
	{
		$this->LocationsModel->delete_plant($id);
		$this->session->set_flashdata('message', 'Plant has been deleted');
		redirect('locations/plants');
	}


}
